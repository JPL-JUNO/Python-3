from setuptools import setup
setup(name="Hello",
      version="0.1",
      description="A simple example",
      author="Stephen CUI",
      author_email='cuixuanstephen@gmail.com',
      py_modules=['hello'])
